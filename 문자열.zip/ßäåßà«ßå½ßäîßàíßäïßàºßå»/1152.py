print(len(input().split()))
