while True: 
    try:
        print(input())
    except:
        break