i=int(input())
S=input()
print(sum(map(int,S)))
