S=input()
i=int(input())
print(S[i-1])