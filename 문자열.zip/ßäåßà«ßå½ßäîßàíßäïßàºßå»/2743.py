S=input()
print(len(S))