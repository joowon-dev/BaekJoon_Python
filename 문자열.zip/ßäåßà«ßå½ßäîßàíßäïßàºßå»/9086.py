for i in range (int(input())):
    S=input()
    print(S[0]+S[len(S)-1])